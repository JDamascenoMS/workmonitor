FT-MONITOR — portable build
============================

To run:
  1. Double-click Run-FT-MONITOR.cmd.
  2. A console window opens (the running server). Your default browser
	 will navigate to https://localhost:7286/.
  3. On first run Windows may warn about the dev HTTPS certificate.
	 If so, run:  dotnet dev-certs https --trust
	 (Requires the .NET SDK; alternatively just click through the warning.)

To stop:
  Close the console window, or press Ctrl+C in it.

What's inside:
  FT-MONITOR.exe        Self-contained single-file app (no .NET install needed).
  Run-FT-MONITOR.cmd    Convenience launcher (sets URL, opens browser).
  appsettings.json      Configuration (Entra auth, GitHub repos, etc.).
  wwwroot/              Static UI assets.

Built on:  2026-05-25 10:00:59
Runtime:   win-x64
