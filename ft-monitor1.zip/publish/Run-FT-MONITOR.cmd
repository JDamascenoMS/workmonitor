@echo off
setlocal
title FT-MONITOR

REM Bind to a fixed local port so the launcher knows where to point the browser.
set ASPNETCORE_URLS=https://localhost:7286;http://localhost:5191
set ASPNETCORE_ENVIRONMENT=Production

REM Start the app in this window. Closing the window stops the server.
start "" "" "https://localhost:7286/"
"%~dp0FT-MONITOR.exe"

endlocal
